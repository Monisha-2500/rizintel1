"""
Labeled evaluation dataset for M3.

Each entry is a DeduplicatedFinding (Section 4 shape) plus a `label` — the
ground-truth classification a human analyst would assign, decided by
reasoning about the scenario BEFORE looking at what the engine outputs.
Some entries are intentionally ambiguous/boundary cases (e.g. strong
consensus but weak evidence text) so the resulting metrics are honest
rather than a trivial 100%.

28 examples, 7 per class, covering:
  - clean/obvious cases for each class
  - boundary cases where signals conflict
  - the two required edge cases (missing CVE, malformed/partial data)
"""

LABELED_DATASET = [
    # -----------------------------------------------------------------
    # CONFIRMED — strong on every signal
    # -----------------------------------------------------------------
    {
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-001", "member_source": "M2",
            "cve_id": "CVE-2026-1234", "vulnerability_name": "SQL Injection",
            "vulnerability_type": "SQL_INJECTION", "severity": "HIGH",
            "asset": {"asset_id": "A-1", "host": "example.com", "endpoint": "/login", "port": 443, "parameter": "username"},
            "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["Z-1", "N-1", "O-1"],
                               "match_method": "HYBRID", "match_score": 0.95,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.98,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.93}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 3, "score": 1.0},
            "source_findings": [{"finding_id": "Z-1", "scanner": "ZAP", "evidence": "SQL error in response"},
                                 {"finding_id": "N-1", "scanner": "NUCLEI", "evidence": "Boolean-based SQLi confirmed"},
                                 {"finding_id": "O-1", "scanner": "OPENVAS", "evidence": "Time-based SQLi confirmed"}],
            "first_seen": "2026-08-14T05:00:00Z", "last_seen": "2026-08-14T05:05:00Z",
        },
    },
    {
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-002", "member_source": "M2",
            "cve_id": "CVE-2026-5566", "vulnerability_name": "Remote Code Execution",
            "vulnerability_type": "RCE", "severity": "CRITICAL",
            "asset": {"asset_id": "A-2", "host": "api.internal", "endpoint": "/upload", "port": 8443, "parameter": "file"},
            "deduplication": {"duplicate_count": 4, "merged_finding_ids": ["Z-2", "N-2", "O-2", "Q-2"],
                               "match_method": "HYBRID", "match_score": 0.97,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 1.0,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.95}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS", "QUALYS"], "detected_by_count": 4, "total_scanners": 4, "score": 1.0},
            "source_findings": [{"finding_id": "Z-2", "scanner": "ZAP", "evidence": "Unrestricted file upload leads to RCE"},
                                 {"finding_id": "N-2", "scanner": "NUCLEI", "evidence": "Webshell upload confirmed"},
                                 {"finding_id": "O-2", "scanner": "OPENVAS", "evidence": "RCE via crafted upload"},
                                 {"finding_id": "Q-2", "scanner": "QUALYS", "evidence": "Arbitrary code execution confirmed"}],
            "first_seen": "2026-08-14T06:00:00Z", "last_seen": "2026-08-14T06:10:00Z",
        },
    },
    {
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-003", "member_source": "M2",
            "cve_id": "CVE-2026-0099", "vulnerability_name": "Authentication Bypass",
            "vulnerability_type": "AUTH_BYPASS", "severity": "CRITICAL",
            "asset": {"asset_id": "A-3", "host": "auth.example.com", "endpoint": "/api/session", "port": 443, "parameter": "token"},
            "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["Z-3", "N-3", "O-3"],
                               "match_method": "HYBRID", "match_score": 0.93,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.95,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.90}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 3, "score": 1.0},
            "source_findings": [{"finding_id": "Z-3", "scanner": "ZAP", "evidence": "JWT signature not verified"},
                                 {"finding_id": "N-3", "scanner": "NUCLEI", "evidence": "Auth bypass via token manipulation"},
                                 {"finding_id": "O-3", "scanner": "OPENVAS", "evidence": "Session forgery confirmed"}],
            "first_seen": "2026-08-14T07:00:00Z", "last_seen": "2026-08-14T07:05:00Z",
        },
    },
    {
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-004", "member_source": "M2",
            "cve_id": "CVE-2026-7788", "vulnerability_name": "XML External Entity Injection",
            "vulnerability_type": "XXE", "severity": "HIGH",
            "asset": {"asset_id": "A-4", "host": "docs.example.com", "endpoint": "/api/parse", "port": 443, "parameter": "xml"},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-4", "N-4"],
                               "match_method": "HYBRID", "match_score": 0.91,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.94,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.92}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 2, "score": 1.0},
            "source_findings": [{"finding_id": "Z-4", "scanner": "ZAP", "evidence": "XXE payload returned file contents"},
                                 {"finding_id": "N-4", "scanner": "NUCLEI", "evidence": "XXE out-of-band confirmed"}],
            "first_seen": "2026-08-14T08:00:00Z", "last_seen": "2026-08-14T08:05:00Z",
        },
    },
    {
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-005", "member_source": "M2",
            "cve_id": "CVE-2026-3344", "vulnerability_name": "Insecure Deserialization",
            "vulnerability_type": "DESERIALIZATION", "severity": "CRITICAL",
            "asset": {"asset_id": "A-5", "host": "internal-api.local", "endpoint": "/rpc", "port": 8080, "parameter": "payload"},
            "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["Z-5", "N-5", "O-5"],
                               "match_method": "HYBRID", "match_score": 0.96,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.97,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.94}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 3, "score": 1.0},
            "source_findings": [{"finding_id": "Z-5", "scanner": "ZAP", "evidence": "Gadget chain executed on server"},
                                 {"finding_id": "N-5", "scanner": "NUCLEI", "evidence": "RCE via deserialization confirmed"},
                                 {"finding_id": "O-5", "scanner": "OPENVAS", "evidence": "Unsafe object deserialization"}],
            "first_seen": "2026-08-14T09:00:00Z", "last_seen": "2026-08-14T09:05:00Z",
        },
    },
    {
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-006", "member_source": "M2",
            "cve_id": "CVE-2026-2211", "vulnerability_name": "Path Traversal",
            "vulnerability_type": "PATH_TRAVERSAL", "severity": "HIGH",
            "asset": {"asset_id": "A-6", "host": "files.example.com", "endpoint": "/download", "port": 443, "parameter": "path"},
            "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["Z-6", "N-6", "O-6"],
                               "match_method": "HYBRID", "match_score": 0.92,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.93,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.90}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 3, "score": 1.0},
            "source_findings": [{"finding_id": "Z-6", "scanner": "ZAP", "evidence": "../../etc/passwd retrieved"},
                                 {"finding_id": "N-6", "scanner": "NUCLEI", "evidence": "Directory traversal confirmed"},
                                 {"finding_id": "O-6", "scanner": "OPENVAS", "evidence": "Arbitrary file read confirmed"}],
            "first_seen": "2026-08-14T10:00:00Z", "last_seen": "2026-08-14T10:05:00Z",
        },
    },
    {
        # required "happy path" case
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "DEDUP-0001", "member_source": "M2",
            "cve_id": "CVE-2026-1234", "vulnerability_name": "SQL Injection",
            "vulnerability_type": "SQL_INJECTION", "severity": "HIGH",
            "asset": {"asset_id": "ASSET-WEB-001", "host": "example.com", "endpoint": "/login", "port": 443, "parameter": "username"},
            "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["ZAP-001", "NUCLEI-044", "OPENVAS-102"],
                               "match_method": "HYBRID", "match_score": 0.94,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.96,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.91}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 3, "score": 1.0},
            "source_findings": [{"finding_id": "ZAP-001", "scanner": "ZAP", "evidence": "SQL error in response body"},
                                 {"finding_id": "NUCLEI-044", "scanner": "NUCLEI", "evidence": "Boolean-based blind SQLi confirmed"},
                                 {"finding_id": "OPENVAS-102", "scanner": "OPENVAS", "evidence": "Time-based SQLi confirmed"}],
            "first_seen": "2026-08-14T05:39:23Z", "last_seen": "2026-08-14T05:41:10Z",
        },
    },

    # -----------------------------------------------------------------
    # HIGH_CONFIDENCE — good but with one weaker dimension
    # -----------------------------------------------------------------
    {
        # required "missing CVE" case — should NOT crater to noise
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-008", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Content Security Policy Header Not Set",
            "vulnerability_type": "SECURITY_HEADER", "severity": "MEDIUM",
            "asset": {"asset_id": "A-8", "host": "localhost", "endpoint": "/", "port": 3000, "parameter": None},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-8", "N-8"],
                               "match_method": "HYBRID", "match_score": 0.88,
                               "match_features": {"cve_match": None, "host_match": 1.0, "endpoint_similarity": 1.0,
                                                   "parameter_match": None, "vulnerability_similarity": 0.85}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-8", "scanner": "ZAP", "evidence": "Missing CSP header in response"},
                                 {"finding_id": "N-8", "scanner": "NUCLEI", "evidence": "No Content-Security-Policy header found"}],
            "first_seen": "2026-08-14T05:00:00Z", "last_seen": "2026-08-14T05:05:00Z",
        },
    },
    {
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-009", "member_source": "M2",
            "cve_id": "CVE-2026-4455", "vulnerability_name": "Cross-Site Scripting",
            "vulnerability_type": "XSS", "severity": "MEDIUM",
            "asset": {"asset_id": "A-9", "host": "shop.example.com", "endpoint": "/search", "port": 443, "parameter": "q"},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-9", "N-9"],
                               "match_method": "HYBRID", "match_score": 0.86,
                               "match_features": {"cve_match": 0.7, "host_match": 1.0, "endpoint_similarity": 0.9,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.88}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-9", "scanner": "ZAP", "evidence": "Reflected XSS confirmed via payload"},
                                 {"finding_id": "N-9", "scanner": "NUCLEI", "evidence": "XSS in search parameter"}],
            "first_seen": "2026-08-14T11:00:00Z", "last_seen": "2026-08-14T11:05:00Z",
        },
    },
    {
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-010", "member_source": "M2",
            "cve_id": "CVE-2026-9911", "vulnerability_name": "Open Redirect",
            "vulnerability_type": "OPEN_REDIRECT", "severity": "LOW",
            "asset": {"asset_id": "A-10", "host": "example.com", "endpoint": "/redirect", "port": 443, "parameter": "url"},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-10", "N-10"],
                               "match_method": "HYBRID", "match_score": 0.83,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.85,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.8}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-10", "scanner": "ZAP", "evidence": "Redirect to attacker-controlled domain"},
                                 {"finding_id": "N-10", "scanner": "NUCLEI", "evidence": "Open redirect confirmed"}],
            "first_seen": "2026-08-14T12:00:00Z", "last_seen": "2026-08-14T12:05:00Z",
        },
    },
    {
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-011", "member_source": "M2",
            "cve_id": "CVE-2026-6622", "vulnerability_name": "Server-Side Request Forgery",
            "vulnerability_type": "SSRF", "severity": "HIGH",
            "asset": {"asset_id": "A-11", "host": "api.example.com", "endpoint": "/fetch", "port": 443, "parameter": "url"},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-11", "N-11"],
                               "match_method": "HYBRID", "match_score": 0.85,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.88,
                                                   "parameter_match": 0.9, "vulnerability_similarity": 0.82}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-11", "scanner": "ZAP", "evidence": "Internal metadata endpoint reached via SSRF"},
                                 {"finding_id": "N-11", "scanner": "NUCLEI", "evidence": "SSRF confirmed via callback"}],
            "first_seen": "2026-08-14T13:00:00Z", "last_seen": "2026-08-14T13:05:00Z",
        },
    },
    {
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-012", "member_source": "M2",
            "cve_id": "CVE-2026-1122", "vulnerability_name": "Broken Access Control",
            "vulnerability_type": "IDOR", "severity": "HIGH",
            "asset": {"asset_id": "A-12", "host": "app.example.com", "endpoint": "/api/user", "port": 443, "parameter": "id"},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-12", "N-12"],
                               "match_method": "HYBRID", "match_score": 0.87,
                               "match_features": {"cve_match": 0.8, "host_match": 1.0, "endpoint_similarity": 0.9,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.86}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-12", "scanner": "ZAP", "evidence": "Accessed another user's record by changing ID"},
                                 {"finding_id": "N-12", "scanner": "NUCLEI", "evidence": "IDOR confirmed"}],
            "first_seen": "2026-08-14T14:00:00Z", "last_seen": "2026-08-14T14:05:00Z",
        },
    },
    {
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-013", "member_source": "M2",
            "cve_id": "CVE-2026-3300", "vulnerability_name": "Weak TLS Configuration",
            "vulnerability_type": "TLS_MISCONFIGURATION", "severity": "MEDIUM",
            "asset": {"asset_id": "A-13", "host": "legacy.example.com", "endpoint": None, "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-13", "N-13"],
                               "match_method": "DETERMINISTIC", "match_score": 0.90,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": None,
                                                   "parameter_match": None, "vulnerability_similarity": 0.88}},
            "scanner_consensus": {"scanner_names": ["ZAP", "OPENVAS"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-13", "scanner": "ZAP", "evidence": "TLS 1.0 still enabled"},
                                 {"finding_id": "N-13", "scanner": "OPENVAS", "evidence": "Weak cipher suites accepted"}],
            "first_seen": "2026-08-14T15:00:00Z", "last_seen": "2026-08-14T15:05:00Z",
        },
    },
    {
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-014", "member_source": "M2",
            "cve_id": "CVE-2026-8800", "vulnerability_name": "Command Injection",
            "vulnerability_type": "COMMAND_INJECTION", "severity": "HIGH",
            "asset": {"asset_id": "A-14", "host": "tools.internal", "endpoint": "/run", "port": 8080, "parameter": "cmd"},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-14", "N-14"],
                               "match_method": "HYBRID", "match_score": 0.84,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.82,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.80}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-14", "scanner": "ZAP", "evidence": "Command output reflected in response"},
                                 {"finding_id": "N-14", "scanner": "NUCLEI", "evidence": "OS command injection confirmed"}],
            "first_seen": "2026-08-14T16:00:00Z", "last_seen": "2026-08-14T16:05:00Z",
        },
    },

    # -----------------------------------------------------------------
    # NEEDS_REVIEW — genuinely ambiguous: signals conflict with each other
    # -----------------------------------------------------------------
    {
        # strong consensus, but zero evidence text and inconsistent match features —
        # a human analyst would want to check this before trusting it
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-015", "member_source": "M2",
            "cve_id": "CVE-2026-2288", "vulnerability_name": "SQL Injection",
            "vulnerability_type": "SQL_INJECTION", "severity": "HIGH",
            "asset": {"asset_id": "A-15", "host": "example.com", "endpoint": "/search", "port": 443, "parameter": "q"},
            "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["Z-15", "N-15", "O-15"],
                               "match_method": "HYBRID", "match_score": 0.70,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.5,
                                                   "parameter_match": 0.4, "vulnerability_similarity": 0.6}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 3, "score": 1.0},
            "source_findings": [{"finding_id": "Z-15", "scanner": "ZAP", "evidence": None},
                                 {"finding_id": "N-15", "scanner": "NUCLEI", "evidence": None},
                                 {"finding_id": "O-15", "scanner": "OPENVAS", "evidence": None}],
            "first_seen": "2026-08-14T17:00:00Z", "last_seen": "2026-08-14T17:05:00Z",
        },
    },
    {
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-016", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Possible Information Disclosure",
            "vulnerability_type": None, "severity": None,
            "asset": {"asset_id": "A-16", "host": "example.com", "endpoint": "/debug", "port": None, "parameter": None},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-16", "N-16"],
                               "match_method": "FUZZY", "match_score": 0.62,
                               "match_features": {"cve_match": None, "host_match": 1.0, "endpoint_similarity": 0.6,
                                                   "parameter_match": None, "vulnerability_similarity": 0.55}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-16", "scanner": "ZAP", "evidence": "Debug endpoint may be exposed"},
                                 {"finding_id": "N-16", "scanner": "NUCLEI", "evidence": None}],
            "first_seen": "2026-08-14T18:00:00Z", "last_seen": "2026-08-14T18:05:00Z",
        },
    },
    {
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-017", "member_source": "M2",
            "cve_id": "CVE-2026-4400", "vulnerability_name": "Outdated Library Version",
            "vulnerability_type": "OUTDATED_COMPONENT", "severity": "LOW",
            "asset": {"asset_id": "A-17", "host": "example.com", "endpoint": "/assets/lib.js", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": 0.55, "match_features": None},
            "scanner_consensus": {"scanner_names": ["NUCLEI"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [{"finding_id": "N-17", "scanner": "NUCLEI", "evidence": "Library version 2.1.0 has known CVE"}],
            "first_seen": "2026-08-14T19:00:00Z", "last_seen": "2026-08-14T19:00:00Z",
        },
    },
    {
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-018", "member_source": "M2",
            "cve_id": "CVE-2026-5511", "vulnerability_name": "Weak Password Policy",
            "vulnerability_type": "WEAK_AUTH", "severity": "MEDIUM",
            "asset": {"asset_id": "A-18", "host": "portal.example.com", "endpoint": "/register", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-18", "O-18"],
                               "match_method": "FUZZY", "match_score": 0.58,
                               "match_features": {"cve_match": 0.3, "host_match": 1.0, "endpoint_similarity": 0.7,
                                                   "parameter_match": None, "vulnerability_similarity": 0.5}},
            "scanner_consensus": {"scanner_names": ["ZAP", "OPENVAS"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-18", "scanner": "ZAP", "evidence": "Weak password accepted"},
                                 {"finding_id": "O-18", "scanner": "OPENVAS", "evidence": None}],
            "first_seen": "2026-08-14T20:00:00Z", "last_seen": "2026-08-14T20:05:00Z",
        },
    },
    {
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-019", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Verbose Error Message",
            "vulnerability_type": "INFO_LEAK", "severity": "LOW",
            "asset": {"asset_id": "A-19", "host": "example.com", "endpoint": "/api/error", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-19", "N-19"],
                               "match_method": "FUZZY", "match_score": 0.60,
                               "match_features": {"cve_match": None, "host_match": 1.0, "endpoint_similarity": 0.65,
                                                   "parameter_match": None, "vulnerability_similarity": 0.5}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-19", "scanner": "ZAP", "evidence": "Stack trace exposed"},
                                 {"finding_id": "N-19", "scanner": "NUCLEI", "evidence": None}],
            "first_seen": "2026-08-14T21:00:00Z", "last_seen": "2026-08-14T21:05:00Z",
        },
    },
    {
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-020", "member_source": "M2",
            "cve_id": "CVE-2026-9900", "vulnerability_name": "Clickjacking",
            "vulnerability_type": "CLICKJACKING", "severity": "LOW",
            "asset": {"asset_id": "A-20", "host": "example.com", "endpoint": "/", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": 0.65, "match_features": None},
            "scanner_consensus": {"scanner_names": ["ZAP"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [{"finding_id": "Z-20", "scanner": "ZAP", "evidence": "X-Frame-Options missing"}],
            "first_seen": "2026-08-14T22:00:00Z", "last_seen": "2026-08-14T22:00:00Z",
        },
    },
    {
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-021", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Directory Listing Enabled",
            "vulnerability_type": "MISCONFIGURATION", "severity": "LOW",
            "asset": {"asset_id": "A-21", "host": "example.com", "endpoint": "/files/", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-21", "N-21"],
                               "match_method": "FUZZY", "match_score": 0.61,
                               "match_features": {"cve_match": None, "host_match": 1.0, "endpoint_similarity": 0.7,
                                                   "parameter_match": None, "vulnerability_similarity": 0.55}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
            "source_findings": [{"finding_id": "Z-21", "scanner": "ZAP", "evidence": "Directory index visible"},
                                 {"finding_id": "N-21", "scanner": "NUCLEI", "evidence": None}],
            "first_seen": "2026-08-14T23:00:00Z", "last_seen": "2026-08-14T23:05:00Z",
        },
    },

    # -----------------------------------------------------------------
    # LIKELY_NOISE — single scanner, weak/no evidence, generic/informational
    # -----------------------------------------------------------------
    {
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-022", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Server Banner Disclosure",
            "vulnerability_type": "INFO_DISCLOSURE", "severity": "LOW",
            "asset": {"asset_id": "A-22", "host": "example.com", "endpoint": "/", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": None, "match_features": None},
            "scanner_consensus": {"scanner_names": ["NUCLEI"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [{"finding_id": "N-22", "scanner": "NUCLEI", "evidence": None}],
            "first_seen": "2026-08-15T00:00:00Z", "last_seen": "2026-08-15T00:00:00Z",
        },
    },
    {
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-023", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Generic Informational Finding",
            "vulnerability_type": None, "severity": None,
            "asset": {"asset_id": "A-23", "host": "test.local", "endpoint": None, "port": None, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": None, "match_features": None},
            "scanner_consensus": {"scanner_names": ["ZAP"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [],
            "first_seen": None, "last_seen": None,
        },
    },
    {
        # required "malformed/partial data" case
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "DEDUP-0003", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Unknown Finding",
            "vulnerability_type": None, "severity": None,
            "asset": {"asset_id": "ASSET-WEB-002", "host": "test.local", "endpoint": None, "port": None, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": None, "match_features": None},
            "scanner_consensus": {"scanner_names": ["ZAP"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [],
            "first_seen": None, "last_seen": None,
        },
    },
    {
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-025", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Cookie Without Secure Flag",
            "vulnerability_type": "COOKIE_MISCONFIG", "severity": "LOW",
            "asset": {"asset_id": "A-25", "host": "example.com", "endpoint": "/", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": 0.3, "match_features": None},
            "scanner_consensus": {"scanner_names": ["ZAP"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [{"finding_id": "Z-25", "scanner": "ZAP", "evidence": None}],
            "first_seen": "2026-08-15T01:00:00Z", "last_seen": "2026-08-15T01:00:00Z",
        },
    },
    {
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-026", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Missing X-Content-Type-Options Header",
            "vulnerability_type": "SECURITY_HEADER", "severity": "LOW",
            "asset": {"asset_id": "A-26", "host": "example.com", "endpoint": "/", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": None, "match_features": None},
            "scanner_consensus": {"scanner_names": ["OPENVAS"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [{"finding_id": "O-26", "scanner": "OPENVAS", "evidence": None}],
            "first_seen": "2026-08-15T02:00:00Z", "last_seen": "2026-08-15T02:00:00Z",
        },
    },
    {
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-027", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "TRACE Method Enabled",
            "vulnerability_type": "HTTP_METHOD", "severity": "LOW",
            "asset": {"asset_id": "A-27", "host": "example.com", "endpoint": "/", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": None, "match_features": None},
            "scanner_consensus": {"scanner_names": ["NUCLEI"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [{"finding_id": "N-27", "scanner": "NUCLEI", "evidence": None}],
            "first_seen": "2026-08-15T03:00:00Z", "last_seen": "2026-08-15T03:00:00Z",
        },
    },
    {
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "L-028", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Self-Signed Certificate Warning",
            "vulnerability_type": "TLS_MISCONFIGURATION", "severity": "LOW",
            "asset": {"asset_id": "A-28", "host": "dev.internal", "endpoint": None, "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": 0.2, "match_features": None},
            "scanner_consensus": {"scanner_names": ["ZAP"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
            "source_findings": [{"finding_id": "Z-28", "scanner": "ZAP", "evidence": None}],
            "first_seen": "2026-08-15T04:00:00Z", "last_seen": "2026-08-15T04:00:00Z",
        },
    },

    # -----------------------------------------------------------------
    # ADVERSARIAL BOUNDARY CASES
    #
    # IMPORTANT: the 28 cases above were authored by the same person who
    # wrote the classifier, using the same mental model of what "should"
    # drive confidence up or down. That means a clean score against them
    # mostly proves the label-writer and the code-writer agreed with
    # themselves, not that the classifier is actually accurate.
    #
    # These additional cases are constructed differently: each one is
    # picked because a reasonable human analyst's snap judgment plausibly
    # DISAGREES with where the formula's specific thresholds land, given
    # signals that are individually strong but not all mutually
    # reinforcing. They're included to produce genuine disagreement in
    # the eval, not to make the numbers look good.
    # -----------------------------------------------------------------
    {
        # 4 scanners agree (very strong raw consensus) but every scanner's
        # evidence field is empty. A human might still call this CONFIRMED
        # on sheer consensus weight; the formula, which treats evidence as
        # an independent signal, may pull it down to HIGH_CONFIDENCE instead.
        "label": "CONFIRMED",
        "finding": {
            "schema_version": "1.0", "finding_id": "B-001", "member_source": "M2",
            "cve_id": "CVE-2026-1001", "vulnerability_name": "SQL Injection",
            "vulnerability_type": "SQL_INJECTION", "severity": "HIGH",
            "asset": {"asset_id": "A-B1", "host": "example.com", "endpoint": "/login", "port": 443, "parameter": "user"},
            "deduplication": {"duplicate_count": 4, "merged_finding_ids": ["Z-B1", "N-B1", "O-B1", "Q-B1"],
                               "match_method": "HYBRID", "match_score": 0.98,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 1.0,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.97}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS", "QUALYS"], "detected_by_count": 4, "total_scanners": 4, "score": 1.0},
            "source_findings": [{"finding_id": "Z-B1", "scanner": "ZAP", "evidence": None},
                                 {"finding_id": "N-B1", "scanner": "NUCLEI", "evidence": None},
                                 {"finding_id": "O-B1", "scanner": "OPENVAS", "evidence": None},
                                 {"finding_id": "Q-B1", "scanner": "QUALYS", "evidence": None}],
            "first_seen": "2026-08-15T05:00:00Z", "last_seen": "2026-08-15T05:05:00Z",
        },
    },
    {
        # Single scanner, but rich, specific evidence text and a real CVE.
        # A human might read the detailed evidence and trust it despite the
        # single-scanner flag; the formula weights scanner_consensus heavily
        # regardless of evidence quality, so it may land lower than a human would.
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "B-002", "member_source": "M2",
            "cve_id": "CVE-2026-1002", "vulnerability_name": "Remote Code Execution",
            "vulnerability_type": "RCE", "severity": "CRITICAL",
            "asset": {"asset_id": "A-B2", "host": "api.example.com", "endpoint": "/upload", "port": 443, "parameter": "file"},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": 1.0, "match_features": None},
            "scanner_consensus": {"scanner_names": ["NUCLEI"], "detected_by_count": 1, "total_scanners": 4, "score": 0.25},
            "source_findings": [{"finding_id": "N-B2", "scanner": "NUCLEI",
                                  "evidence": "Confirmed RCE: uploaded a .php webshell, executed 'id' command, received uid=33(www-data) in response. Full request/response captured."}],
            "first_seen": "2026-08-15T06:00:00Z", "last_seen": "2026-08-15T06:00:00Z",
        },
    },
    {
        # Two scanners, moderate match_score right at the CONFIRMED/HIGH_CONFIDENCE
        # boundary, with one weak match_feature dragging consistency down.
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "B-003", "member_source": "M2",
            "cve_id": "CVE-2026-1003", "vulnerability_name": "Cross-Site Scripting",
            "vulnerability_type": "XSS", "severity": "MEDIUM",
            "asset": {"asset_id": "A-B3", "host": "shop.example.com", "endpoint": "/product", "port": 443, "parameter": "id"},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-B3", "N-B3"],
                               "match_method": "HYBRID", "match_score": 0.90,
                               "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.4,
                                                   "parameter_match": 1.0, "vulnerability_similarity": 0.85}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 4, "score": 0.5},
            "source_findings": [{"finding_id": "Z-B3", "scanner": "ZAP", "evidence": "Reflected XSS payload executed"},
                                 {"finding_id": "N-B3", "scanner": "NUCLEI", "evidence": "XSS confirmed"}],
            "first_seen": "2026-08-15T07:00:00Z", "last_seen": "2026-08-15T07:05:00Z",
        },
    },
    {
        # Right at the NEEDS_REVIEW / LIKELY_NOISE boundary: single scanner,
        # but a named CVE and specific (if brief) evidence. Arguably worth a
        # human glance rather than auto-discarding as noise.
        "label": "NEEDS_REVIEW",
        "finding": {
            "schema_version": "1.0", "finding_id": "B-004", "member_source": "M2",
            "cve_id": "CVE-2026-1004", "vulnerability_name": "Outdated OpenSSL Version",
            "vulnerability_type": "OUTDATED_COMPONENT", "severity": "MEDIUM",
            "asset": {"asset_id": "A-B4", "host": "example.com", "endpoint": None, "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                               "match_score": 0.75, "match_features": None},
            "scanner_consensus": {"scanner_names": ["OPENVAS"], "detected_by_count": 1, "total_scanners": 4, "score": 0.25},
            "source_findings": [{"finding_id": "O-B4", "scanner": "OPENVAS", "evidence": "OpenSSL 1.0.2 detected, matches CVE-2026-1004"}],
            "first_seen": "2026-08-15T08:00:00Z", "last_seen": "2026-08-15T08:00:00Z",
        },
    },
    {
        # 3 scanners agree, but match_score is surprisingly low (M2 itself
        # was unsure about the merge) and all match_features are moderate-low.
        # Human intuition might trust the raw scanner count; formula may not.
        "label": "HIGH_CONFIDENCE",
        "finding": {
            "schema_version": "1.0", "finding_id": "B-005", "member_source": "M2",
            "cve_id": "CVE-2026-1005", "vulnerability_name": "Insecure Direct Object Reference",
            "vulnerability_type": "IDOR", "severity": "HIGH",
            "asset": {"asset_id": "A-B5", "host": "app.example.com", "endpoint": "/api/order", "port": 443, "parameter": "order_id"},
            "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["Z-B5", "N-B5", "O-B5"],
                               "match_method": "FUZZY", "match_score": 0.55,
                               "match_features": {"cve_match": 0.5, "host_match": 1.0, "endpoint_similarity": 0.6,
                                                   "parameter_match": 0.5, "vulnerability_similarity": 0.5}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 4, "score": 0.75},
            "source_findings": [{"finding_id": "Z-B5", "scanner": "ZAP", "evidence": "Accessed order belonging to another user"},
                                 {"finding_id": "N-B5", "scanner": "NUCLEI", "evidence": "IDOR pattern detected"},
                                 {"finding_id": "O-B5", "scanner": "OPENVAS", "evidence": "Unauthorized object access"}],
            "first_seen": "2026-08-15T09:00:00Z", "last_seen": "2026-08-15T09:05:00Z",
        },
    },
    {
        # Generic/low-severity finding but 2 scanners and decent match —
        # a human might dismiss this as noise regardless of the numbers,
        # since it's a well-known low-value finding type.
        "label": "LIKELY_NOISE",
        "finding": {
            "schema_version": "1.0", "finding_id": "B-006", "member_source": "M2",
            "cve_id": None, "vulnerability_name": "Missing HSTS Header",
            "vulnerability_type": "SECURITY_HEADER", "severity": "LOW",
            "asset": {"asset_id": "A-B6", "host": "example.com", "endpoint": "/", "port": 443, "parameter": None},
            "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["Z-B6", "N-B6"],
                               "match_method": "HYBRID", "match_score": 0.80,
                               "match_features": {"cve_match": None, "host_match": 1.0, "endpoint_similarity": 1.0,
                                                   "parameter_match": None, "vulnerability_similarity": 0.75}},
            "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 4, "score": 0.5},
            "source_findings": [{"finding_id": "Z-B6", "scanner": "ZAP", "evidence": "HSTS header not present"},
                                 {"finding_id": "N-B6", "scanner": "NUCLEI", "evidence": "Missing Strict-Transport-Security"}],
            "first_seen": "2026-08-15T10:00:00Z", "last_seen": "2026-08-15T10:05:00Z",
        },
    },
]
