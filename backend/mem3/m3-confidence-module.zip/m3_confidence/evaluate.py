"""
Evaluates M3's confidence classifier against the hand-labeled dataset in
data/labeled_dataset.py.

Reports:
  - Confusion matrix
  - Precision / recall / F1 per class
  - Macro-averaged precision / recall / F1
  - Overall accuracy
  - Noise suppression rate: recall on LIKELY_NOISE (of all true noise,
    what fraction did we correctly flag as noise?)
  - Critical miss rate: of all true CONFIRMED/HIGH_CONFIDENCE findings
    (i.e. real, actionable vulnerabilities), what fraction did we
    wrongly suppress as LIKELY_NOISE? This is the dangerous error type —
    a real vulnerability getting thrown away — so it's reported
    separately from ordinary misclassification.

Run: python3 evaluate.py
"""

import sys
from pathlib import Path
from collections import defaultdict

sys.path.insert(0, str(Path(__file__).parent))

from schemas import DeduplicatedFinding
from confidence_engine import assess_confidence
from data.labeled_dataset import LABELED_DATASET

CLASSES = ["CONFIRMED", "HIGH_CONFIDENCE", "NEEDS_REVIEW", "LIKELY_NOISE"]


def run_predictions():
    y_true, y_pred, records = [], [], []
    for entry in LABELED_DATASET:
        finding = DeduplicatedFinding(**entry["finding"])
        result = assess_confidence(finding)
        y_true.append(entry["label"])
        y_pred.append(result.finding_confidence.classification)
        records.append((finding.finding_id, entry["label"],
                         result.finding_confidence.classification,
                         result.finding_confidence.score))
    return y_true, y_pred, records


def confusion_matrix(y_true, y_pred):
    matrix = {a: {p: 0 for p in CLASSES} for a in CLASSES}
    for t, p in zip(y_true, y_pred):
        matrix[t][p] += 1
    return matrix


def precision_recall_f1(matrix):
    results = {}
    for cls in CLASSES:
        tp = matrix[cls][cls]
        fp = sum(matrix[other][cls] for other in CLASSES if other != cls)
        fn = sum(matrix[cls][other] for other in CLASSES if other != cls)

        precision = tp / (tp + fp) if (tp + fp) > 0 else float("nan")
        recall = tp / (tp + fn) if (tp + fn) > 0 else float("nan")
        f1 = (2 * precision * recall / (precision + recall)
              if (precision + recall) > 0 and not (precision != precision) and not (recall != recall)
              else float("nan"))
        results[cls] = {"precision": precision, "recall": recall, "f1": f1, "support": tp + fn}
    return results


def print_report():
    y_true, y_pred, records = run_predictions()
    matrix = confusion_matrix(y_true, y_pred)
    metrics = precision_recall_f1(matrix)

    total = len(y_true)
    correct = sum(1 for t, p in zip(y_true, y_pred) if t == p)
    accuracy = correct / total

    print("=" * 72)
    print(f"M3 CONFIDENCE CLASSIFIER — EVALUATION ({total} labeled examples)")
    print("=" * 72)

    print("\n--- Confusion matrix (rows = true label, cols = predicted) ---")
    header = " " * 18 + "".join(f"{c[:12]:>14}" for c in CLASSES)
    print(header)
    for true_cls in CLASSES:
        row = f"{true_cls:<18}" + "".join(f"{matrix[true_cls][pred_cls]:>14}" for pred_cls in CLASSES)
        print(row)

    print("\n--- Per-class metrics ---")
    print(f"{'Class':<18}{'Precision':>12}{'Recall':>12}{'F1':>12}{'Support':>10}")
    for cls in CLASSES:
        m = metrics[cls]
        def fmt(x): return f"{x:.3f}" if x == x else "  n/a"
        print(f"{cls:<18}{fmt(m['precision']):>12}{fmt(m['recall']):>12}{fmt(m['f1']):>12}{m['support']:>10}")

    valid = [m for m in metrics.values() if m["precision"] == m["precision"]]
    macro_p = sum(m["precision"] for m in valid) / len(valid)
    macro_r = sum(m["recall"] for m in valid) / len(valid)
    macro_f1 = sum(m["f1"] for m in valid if m["f1"] == m["f1"]) / len([m for m in valid if m["f1"] == m["f1"]])

    print(f"\n{'Macro avg':<18}{macro_p:>12.3f}{macro_r:>12.3f}{macro_f1:>12.3f}{total:>10}")
    print(f"\nOverall accuracy: {accuracy:.3f} ({correct}/{total})")

    # --- Noise suppression / critical miss ---
    true_noise = [(t, p) for t, p in zip(y_true, y_pred) if t == "LIKELY_NOISE"]
    noise_recall = sum(1 for t, p in true_noise if p == "LIKELY_NOISE") / len(true_noise) if true_noise else float("nan")

    true_real = [(t, p) for t, p in zip(y_true, y_pred) if t in ("CONFIRMED", "HIGH_CONFIDENCE")]
    critical_misses = [(t, p) for t, p in true_real if p == "LIKELY_NOISE"]
    critical_miss_rate = len(critical_misses) / len(true_real) if true_real else float("nan")

    print("\n--- Noise handling ---")
    print(f"Noise suppression rate (recall on LIKELY_NOISE): {noise_recall:.3f}")
    print(f"Critical miss rate (real findings wrongly marked noise): {critical_miss_rate:.3f}")
    if critical_misses:
        print("  Critical misses:")
        for finding_id, true_label, pred_label, score in records:
            if true_label in ("CONFIRMED", "HIGH_CONFIDENCE") and pred_label == "LIKELY_NOISE":
                print(f"    {finding_id}: true={true_label}, predicted={pred_label}, score={score}")

    # --- All misclassifications, for debugging threshold tuning ---
    print("\n--- All misclassifications ---")
    any_wrong = False
    for finding_id, true_label, pred_label, score in records:
        if true_label != pred_label:
            any_wrong = True
            print(f"  {finding_id}: true={true_label:<16} predicted={pred_label:<16} score={score}")
    if not any_wrong:
        print("  (none)")

    print("\n" + "=" * 72)


if __name__ == "__main__":
    print_report()
