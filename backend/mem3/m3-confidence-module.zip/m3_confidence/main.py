"""
M3 Confidence/Noise service.

Run:
    uvicorn main:app --reload --port 8003

Endpoints:
    GET  /                         health check
    GET  /sample-input             a mock DeduplicatedFinding matching Section 4,
                                    for M2 or downstream devs to test against
    POST /assess                   single DeduplicatedFinding -> ConfidenceEnrichedFinding
    POST /assess/batch             list[DeduplicatedFinding] -> list[ConfidenceEnrichedFinding]

No dedup, threat intel, risk scoring, SLA, or dashboard logic lives here —
this service does exactly one thing: Section 4 in, Section 5 out.
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from schemas import ConfidenceEnrichedFinding, DeduplicatedFinding
from confidence_engine import assess_confidence

app = FastAPI(title="M3 — Confidence / Noise Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


SAMPLE_INPUT = {
    "schema_version": "1.0",
    "finding_id": "DEDUP-0001",
    "member_source": "M2",
    "cve_id": "CVE-2026-1234",
    "vulnerability_name": "SQL Injection",
    "vulnerability_type": "SQL_INJECTION",
    "severity": "HIGH",
    "asset": {
        "asset_id": "ASSET-WEB-001",
        "host": "example.com",
        "endpoint": "/login",
        "port": 443,
        "parameter": "username",
    },
    "deduplication": {
        "duplicate_count": 3,
        "merged_finding_ids": ["ZAP-001", "NUCLEI-044", "OPENVAS-102"],
        "match_method": "HYBRID",
        "match_score": 0.94,
        "match_features": {
            "cve_match": 1.0,
            "host_match": 1.0,
            "endpoint_similarity": 0.96,
            "parameter_match": 1.0,
            "vulnerability_similarity": 0.91,
        },
    },
    "scanner_consensus": {
        "scanner_names": ["ZAP", "NUCLEI", "OPENVAS"],
        "detected_by_count": 3,
        "total_scanners": 3,
        "score": 1.0,
    },
    "source_findings": [
        {"finding_id": "ZAP-001", "scanner": "ZAP", "evidence": "SQL error in response body"},
        {"finding_id": "NUCLEI-044", "scanner": "NUCLEI", "evidence": "Boolean-based blind SQLi confirmed"},
        {"finding_id": "OPENVAS-102", "scanner": "OPENVAS", "evidence": "Time-based SQLi confirmed"},
    ],
    "first_seen": "2026-08-14T05:39:23Z",
    "last_seen": "2026-08-14T05:41:10Z",
}


@app.get("/")
def health():
    return {"status": "ok", "module": "M3-confidence-noise", "schema_version": "1.0"}


@app.get("/sample-input")
def sample_input():
    return SAMPLE_INPUT


@app.post("/assess", response_model=ConfidenceEnrichedFinding)
def assess(finding: DeduplicatedFinding):
    return assess_confidence(finding)


@app.post("/assess/batch", response_model=list[ConfidenceEnrichedFinding])
def assess_batch(findings: list[DeduplicatedFinding]):
    return [assess_confidence(f) for f in findings]
