"""
The three test cases required by PS4 Interface Contract Section 13:
"validate at least one happy-path case, one missing-CVE case, and one
malformed/partial-data case."

Run: pytest tests/test_m3.py -v
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from schemas import DeduplicatedFinding, ConfidenceEnrichedFinding
from confidence_engine import assess_confidence


def test_happy_path():
    """3-scanner consensus, full evidence, complete data -> CONFIRMED."""
    finding = DeduplicatedFinding(**{
        "schema_version": "1.0", "finding_id": "DEDUP-0001", "member_source": "M2",
        "cve_id": "CVE-2026-1234", "vulnerability_name": "SQL Injection",
        "vulnerability_type": "SQL_INJECTION", "severity": "HIGH",
        "asset": {"asset_id": "ASSET-WEB-001", "host": "example.com", "endpoint": "/login", "port": 443, "parameter": "username"},
        "deduplication": {"duplicate_count": 3, "merged_finding_ids": ["ZAP-001", "NUCLEI-044", "OPENVAS-102"],
                           "match_method": "HYBRID", "match_score": 0.94,
                           "match_features": {"cve_match": 1.0, "host_match": 1.0, "endpoint_similarity": 0.96,
                                               "parameter_match": 1.0, "vulnerability_similarity": 0.91}},
        "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI", "OPENVAS"], "detected_by_count": 3, "total_scanners": 3, "score": 1.0},
        "source_findings": [{"finding_id": "ZAP-001", "scanner": "ZAP", "evidence": "SQL error in response body"},
                             {"finding_id": "NUCLEI-044", "scanner": "NUCLEI", "evidence": "Boolean-based blind SQLi confirmed"},
                             {"finding_id": "OPENVAS-102", "scanner": "OPENVAS", "evidence": "Time-based SQLi confirmed"}],
        "first_seen": "2026-08-14T05:39:23Z", "last_seen": "2026-08-14T05:41:10Z",
    })

    result = assess_confidence(finding)

    assert isinstance(result, ConfidenceEnrichedFinding)
    assert result.finding_id == "DEDUP-0001"
    assert result.cve_id == "CVE-2026-1234"          # preserved per Section 13 rule
    assert result.finding_confidence.classification == "CONFIRMED"
    assert result.finding_confidence.score >= 0.90
    assert result.finding_confidence.review_required is False
    assert result.noise_assessment.likely_noise is False
    assert result.source_findings == ["ZAP-001", "NUCLEI-044", "OPENVAS-102"]  # evidence preserved as IDs


def test_missing_cve():
    """
    No CVE (legitimate — e.g. missing security header). Must NOT crater
    to LIKELY_NOISE just because cve_id is null; other signals still carry it.
    """
    finding = DeduplicatedFinding(**{
        "schema_version": "1.0", "finding_id": "DEDUP-0002", "member_source": "M2",
        "cve_id": None, "vulnerability_name": "Content Security Policy Header Not Set",
        "vulnerability_type": "SECURITY_HEADER", "severity": "MEDIUM",
        "asset": {"asset_id": "ASSET-WEB-001", "host": "localhost", "endpoint": "/", "port": 3000, "parameter": None},
        "deduplication": {"duplicate_count": 2, "merged_finding_ids": ["ZAP-010", "NUCLEI-020"],
                           "match_method": "HYBRID", "match_score": 0.88,
                           "match_features": {"cve_match": None, "host_match": 1.0, "endpoint_similarity": 1.0,
                                               "parameter_match": None, "vulnerability_similarity": 0.85}},
        "scanner_consensus": {"scanner_names": ["ZAP", "NUCLEI"], "detected_by_count": 2, "total_scanners": 3, "score": 0.667},
        "source_findings": [{"finding_id": "ZAP-010", "scanner": "ZAP", "evidence": "Missing CSP header in response"},
                             {"finding_id": "NUCLEI-020", "scanner": "NUCLEI", "evidence": "No Content-Security-Policy header found"}],
        "first_seen": "2026-08-14T05:00:00Z", "last_seen": "2026-08-14T05:05:00Z",
    })

    result = assess_confidence(finding)

    assert result.cve_id is None
    assert result.finding_confidence.classification != "LIKELY_NOISE", \
        "Missing CVE alone must not push a well-corroborated finding to noise"
    assert "MISSING_CVE_ID" in result.finding_confidence.reason_codes
    assert result.finding_confidence.score > 0.5


def test_malformed_partial_data():
    """
    Almost everything null/empty: no CVE, no type, no severity, no
    endpoint/port, no match_score, no match_features, no source_findings,
    single scanner. Must not crash, must return a valid schema, and should
    land as LIKELY_NOISE given how little supports it.
    """
    finding = DeduplicatedFinding(**{
        "schema_version": "1.0", "finding_id": "DEDUP-0003", "member_source": "M2",
        "cve_id": None, "vulnerability_name": "Unknown Finding",
        "vulnerability_type": None, "severity": None,
        "asset": {"asset_id": "ASSET-WEB-002", "host": "test.local", "endpoint": None, "port": None, "parameter": None},
        "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                           "match_score": None, "match_features": None},
        "scanner_consensus": {"scanner_names": ["ZAP"], "detected_by_count": 1, "total_scanners": 3, "score": 0.333},
        "source_findings": [],
        "first_seen": None, "last_seen": None,
    })

    # Must not raise
    result = assess_confidence(finding)

    assert isinstance(result, ConfidenceEnrichedFinding)
    assert result.finding_id == "DEDUP-0003"
    assert result.finding_confidence.classification == "LIKELY_NOISE"
    assert result.noise_assessment.likely_noise is True
    assert result.noise_assessment.reason is not None
    assert 0.0 <= result.finding_confidence.score <= 1.0
    assert result.source_findings == []


def test_output_never_mutates_canonical_ids():
    """Sanity check on Section 13's rule: finding_id/cve_id/asset_id survive unchanged."""
    finding = DeduplicatedFinding(**{
        "schema_version": "1.0", "finding_id": "DEDUP-9999", "member_source": "M2",
        "cve_id": "CVE-2026-9999", "vulnerability_name": "Test Vuln",
        "vulnerability_type": "TEST", "severity": "LOW",
        "asset": {"asset_id": "ASSET-TEST-001", "host": "test.com", "endpoint": "/x", "port": 80, "parameter": None},
        "deduplication": {"duplicate_count": 1, "merged_finding_ids": [], "match_method": "NONE",
                           "match_score": 0.5, "match_features": None},
        "scanner_consensus": {"scanner_names": ["ZAP"], "detected_by_count": 1, "total_scanners": 1, "score": 1.0},
        "source_findings": [{"finding_id": "ZAP-999", "scanner": "ZAP", "evidence": "test"}],
        "first_seen": "2026-08-14T00:00:00Z", "last_seen": "2026-08-14T00:00:00Z",
    })
    result = assess_confidence(finding)
    assert result.finding_id == "DEDUP-9999"
    assert result.cve_id == "CVE-2026-9999"
    assert result.asset.asset_id == "ASSET-TEST-001"


if __name__ == "__main__":
    test_happy_path()
    test_missing_cve()
    test_malformed_partial_data()
    test_output_never_mutates_canonical_ids()
    print("All 4 tests passed.")
